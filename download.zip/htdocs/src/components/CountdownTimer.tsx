import React, { useState, useEffect } from 'react';
import { Clock, Flame } from 'lucide-react';

const CountdownTimer: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 59,
    seconds: 59
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        const { hours, minutes, seconds } = prev;
        
        if (seconds > 0) {
          return { ...prev, seconds: seconds - 1 };
        } else if (minutes > 0) {
          return { hours, minutes: minutes - 1, seconds: 59 };
        } else if (hours > 0) {
          return { hours: hours - 1, minutes: 59, seconds: 59 };
        } else {
          return { hours: 23, minutes: 59, seconds: 59 }; // Reset to 24 hours
        }
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatNumber = (num: number) => num.toString().padStart(2, '0');

  return (
    <div className="relative">
      <div className="absolute inset-0 bg-gradient-to-r from-red-500 to-orange-500 rounded-lg blur-lg opacity-50 animate-pulse" />
      <div className="relative bg-gradient-to-r from-red-600 to-orange-600 text-white px-6 py-3 rounded-lg flex items-center gap-4 shadow-2xl">
        <div className="flex items-center gap-2">
          <Flame className="w-5 h-5 animate-bounce" />
          <span className="font-bold text-sm">SPECIAL OFFER</span>
        </div>
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4" />
          <div className="flex gap-1 font-mono font-bold">
            <span className="bg-black/30 px-2 py-1 rounded">{formatNumber(timeLeft.hours)}</span>
            <span>:</span>
            <span className="bg-black/30 px-2 py-1 rounded">{formatNumber(timeLeft.minutes)}</span>
            <span>:</span>
            <span className="bg-black/30 px-2 py-1 rounded">{formatNumber(timeLeft.seconds)}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CountdownTimer;
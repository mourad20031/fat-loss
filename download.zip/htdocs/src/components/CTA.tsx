import React from 'react';
import { Download, Shield, Users, Star, Clock, MessageCircle } from 'lucide-react';

const CTA: React.FC = () => {
  const features = [
    {
      icon: Shield,
      title: '100% Virus Free',
      description: 'All mods are scanned and safe'
    },
    {
      icon: Users,
      title: '500K+ Happy Users',
      description: 'Trusted by gamers worldwide'
    },
    {
      icon: Star,
      title: '4.9/5 Rating',
      description: 'Excellent user reviews'
    },
    {
      icon: Clock,
      title: '24/7 Support',
      description: 'Always here to help you'
    }
  ];

  return (
    <section id="cta" className="py-20 px-6 bg-gradient-to-br from-purple-600 via-purple-700 to-purple-800 relative overflow-hidden">
      {/* Pattern Background */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />

      <div className="container mx-auto max-w-6xl relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Start Your Gaming Journey Today!
          </h2>
          <p className="text-xl md:text-2xl text-white/90 max-w-3xl mx-auto mb-12">
            Join 500,000+ gamers already using our premium mods. Download instantly and dominate every game!
          </p>

          {/* Main CTA Button */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16">
            <button className="group relative flex items-center justify-center px-8 py-4 bg-gradient-to-r from-amber-400 to-amber-600 text-gray-900 rounded-lg font-bold text-lg shadow-xl hover:scale-105 transform transition-all duration-300">
              <Download className="w-6 h-6 mr-2" />
              Download All Mods FREE
            </button>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {/* Why Choose Us */}
            <div>
              <h3 className="text-2xl font-bold text-white mb-6">
                Why Choose Us?
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {features.map((feature, index) => (
                  <div
                    key={feature.title}
                    className="bg-white/10 backdrop-blur-sm rounded-lg p-4 text-center hover:bg-white/20 transition-all duration-300"
                  >
                    <div className="w-10 h-10 bg-gradient-to-r from-amber-400 to-amber-600 text-gray-900 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <feature.icon className="w-5 h-5" />
                    </div>
                    <h4 className="text-white font-semibold mb-1 text-sm">
                      {feature.title}
                    </h4>
                    <p className="text-white/80 text-xs">
                      {feature.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Custom Mods */}
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <h3 className="text-2xl font-bold text-white mb-2 text-center">
                Need Custom Mods?
              </h3>
              <p className="text-white/80 text-center mb-6">
                Contact us for special requests or if you need help with any mods
              </p>
              <button
                onClick={() => {
                  const element = document.querySelector('#contact');
                  if (element) {
                    element.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                className="block w-full bg-gradient-to-r from-amber-400 to-amber-600 text-gray-900 py-3 px-6 rounded-lg font-bold text-center hover:opacity-90 transition-opacity"
              >
                <MessageCircle className="w-5 h-5 inline mr-2" />
                Contact Support
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;
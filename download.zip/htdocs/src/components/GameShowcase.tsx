import React, { useState, useMemo } from 'react';
import { Download, Star, Shield, Zap } from 'lucide-react';
import GameCard from './GameCard';
import { games } from '../data/games';
import { Game } from '../types';

const GameShowcase: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', name: 'All Games' },
    { id: 'action', name: 'Action' },
    { id: 'adventure', name: 'Adventure' },
    { id: 'arcade', name: 'Arcade' },
    { id: 'battle-royale', name: 'Battle Royale' },
    { id: 'strategy', name: 'Strategy' },
    { id: 'sports', name: 'Sports' },
    { id: 'puzzle', name: 'Puzzle' },
    { id: 'racing', name: 'Racing' },
  ];

  const filteredGames = useMemo(() => {
    let filtered = games;

    if (searchQuery) {
      filtered = filtered.filter(game =>
        game.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        game.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(game =>
        game.category.toLowerCase().includes(selectedCategory.toLowerCase())
      );
    }

    return filtered;
  }, [searchQuery, selectedCategory]);

  const displayGames = filteredGames.slice(0, 20); // Show first 20 games

  return (
    <section id="games" className="py-20 px-6 bg-zinc-50">
      <div className="container mx-auto max-w-7xl">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-zinc-900 mb-6">
            20+ Premium Game Mods
          </h2>
          <p className="text-xl text-zinc-700 max-w-2xl mx-auto">
            Choose from our extensive collection of game modifications. All mods are tested, safe, and updated regularly.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col gap-4 mb-8">
          {/* Search Bar */}
          <div className="relative">
            <input
              type="text"
              placeholder="Search for your favorite games..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-4 py-3 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
            />
          </div>

          {/* Category Filters */}
          <div className="flex flex-wrap gap-2 justify-center">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
                  selectedCategory === category.id
                    ? 'bg-gradient-to-r from-purple-600 to-purple-800 text-white'
                    : 'bg-white border border-zinc-300 text-zinc-700 hover:bg-zinc-50'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>

        {/* Results Count */}
        <div className="text-center mb-8">
          <p className="text-zinc-600">
            Showing <span className="font-semibold text-zinc-900">{displayGames.length}</span> of{' '}
            <span className="font-semibold text-zinc-900">{filteredGames.length}</span> games
          </p>
        </div>

        {/* Games Grid - 2x2 for mobile, 4x4 for desktop */}
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-6">
          {displayGames.map((game, index) => (
            <div
              key={game.id}
              className="transition-all duration-700"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <GameCard game={game} />
            </div>
          ))}
        </div>

        {/* Load More Button */}
        {filteredGames.length > 20 && (
          <div className="text-center mt-12">
            <button className="px-8 py-3 border-2 border-purple-600 text-purple-600 rounded-lg font-semibold hover:bg-purple-600 hover:text-white transition-all duration-200">
              Load More Games
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default GameShowcase;
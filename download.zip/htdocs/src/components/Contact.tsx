import React, { useState } from 'react';
import { Mail, MessageCircle, Send } from 'lucide-react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    game: '',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    console.log('Form submitted:', formData);
  };

  if (isSubmitted) {
    return (
      <section id="contact" className="py-20 px-6 bg-zinc-50">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-zinc-900 mb-6">
              Get in Touch
            </h2>
          </div>

          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-lg p-8 shadow-sm border border-zinc-200 text-center">
              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Send className="text-white text-2xl" />
              </div>
              <h3 className="text-2xl font-bold text-zinc-900 mb-2">
                Message Sent Successfully!
              </h3>
              <p className="text-zinc-700">
                We'll get back to you within 24 hours.
              </p>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="contact" className="py-20 px-6 bg-zinc-50">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-zinc-900 mb-6">
            Get in Touch
          </h2>
          <p className="text-xl text-zinc-700 max-w-2xl mx-auto">
            Need custom mods or have questions? We're here to help you level up your gaming experience.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Left Side - Why Contact */}
          <div>
            <h3 className="text-2xl font-bold text-zinc-900 mb-6">
              Why Contact Us?
            </h3>
            <p className="text-zinc-700 mb-6">
              Whether you need custom mods, have technical issues, or want to request specific features, our team is ready to help.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-white p-6 rounded-lg border border-zinc-200 hover:shadow-lg transition-all duration-300">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-purple-800 text-white rounded-lg flex items-center justify-center mb-4">
                  <Mail className="w-5 h-5" />
                </div>
                <h4 className="font-semibold text-zinc-900 mb-2">
                  Email Support
                </h4>
                <p className="text-sm text-zinc-700 mb-2">
                  Get help via email within 24 hours
                </p>
                <p className="text-sm font-medium text-purple-600">
                  support@gamemodspro.com
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg border border-zinc-200 hover:shadow-lg transition-all duration-300">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-purple-800 text-white rounded-lg flex items-center justify-center mb-4">
                  <MessageCircle className="w-5 h-5" />
                </div>
                <h4 className="font-semibold text-zinc-900 mb-2">
                  Live Chat
                </h4>
                <p className="text-sm text-zinc-700 mb-2">
                  Chat with our support team
                </p>
                <p className="text-sm font-medium text-purple-600">
                  Available 9 AM - 9 PM EST
                </p>
              </div>
            </div>
          </div>

          {/* Right Side - Contact Form */}
          <div className="bg-white rounded-lg p-8 shadow-sm border border-zinc-200">
            <h3 className="text-2xl font-bold text-zinc-900 mb-6 text-center">
              Send Us a Message
            </h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-zinc-700 mb-2">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                    placeholder="Enter your name"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-zinc-700 mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                    placeholder="your@email.com"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-700 mb-2">
                  Game You Need Mods For *
                </label>
                <select
                  name="game"
                  value={formData.game}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                  required
                >
                  <option value="">Select a game...</option>
                  <option value="pubg">PUBG Mobile</option>
                  <option value="freefire">Free Fire</option>
                  <option value="cod">Call of Duty Mobile</option>
                  <option value="ml">Mobile Legends</option>
                  <option value="coc">Clash of Clans</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-700 mb-2">
                  Your Message *
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  rows={5}
                  className="w-full px-4 py-3 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent resize-none"
                  placeholder="Tell us what mods you need or any questions you have..."
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-amber-400 to-amber-600 text-gray-900 py-4 px-6 rounded-lg font-bold hover:opacity-90 transition-opacity hover:scale-105 transform duration-300"
              >
                <Send className="w-5 h-5 inline mr-2" />
                Send Message
              </button>

              <p className="text-xs text-zinc-500 text-center">
                We respect your privacy. Your information will never be shared with third parties.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
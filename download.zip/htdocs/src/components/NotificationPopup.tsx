import React, { useState, useEffect } from 'react';
import { Download, MapPin, Star } from 'lucide-react';

interface Notification {
  id: number;
  user: string;
  location: string;
  game: string;
  time: string;
}

const NotificationPopup: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [visibleId, setVisibleId] = useState<number | null>(null);

  const sampleNotifications: Omit<Notification, 'id'>[] = [
    { user: 'Alex', location: 'New York', game: 'PUBG Mobile', time: 'Just now' },
    { user: 'Sarah', location: 'London', game: 'Free Fire', time: '2 min ago' },
    { user: 'Mike', location: 'Tokyo', game: 'Call of Duty', time: '5 min ago' },
    { user: 'Emma', location: 'Paris', game: 'Mobile Legends', time: '8 min ago' },
    { user: 'John', location: 'Sydney', game: 'Clash of Clans', time: '12 min ago' },
    { user: 'Lisa', location: 'Toronto', game: 'Garena Free Fire', time: '15 min ago' },
    { user: 'David', location: 'Mumbai', game: 'PUBG Mobile', time: '18 min ago' },
    { user: 'Amy', location: 'Dubai', game: 'Call of Duty', time: '22 min ago' },
  ];

  useEffect(() => {
    // Show first notification after 3 seconds
    const initialTimer = setTimeout(() => {
      showRandomNotification();
    }, 3000);

    // Show notifications every 8-12 seconds
    const notificationTimer = setInterval(() => {
      showRandomNotification();
    }, Math.random() * 4000 + 8000);

    return () => {
      clearTimeout(initialTimer);
      clearInterval(notificationTimer);
    };
  }, []);

  const showRandomNotification = () => {
    const randomNotification = sampleNotifications[Math.floor(Math.random() * sampleNotifications.length)];
    const newNotification: Notification = {
      ...randomNotification,
      id: Date.now()
    };

    setNotifications(prev => [...prev, newNotification]);
    setVisibleId(newNotification.id);

    // Hide after 5 seconds
    setTimeout(() => {
      setVisibleId(null);
      // Remove from array after animation
      setTimeout(() => {
        setNotifications(prev => prev.filter(n => n.id !== newNotification.id));
      }, 500);
    }, 5000);
  };

  if (notifications.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 space-y-2">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className={`bg-white rounded-lg shadow-2xl border border-zinc-200 p-4 min-w-[300px] transform transition-all duration-500 ${
            visibleId === notification.id
              ? 'translate-x-0 opacity-100 scale-100'
              : 'translate-x-full opacity-0 scale-95'
          }`}
        >
          <div className="flex items-start gap-3">
            <div className="bg-green-500 rounded-full p-2 flex-shrink-0">
              <Download className="w-4 h-4 text-white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-semibold text-zinc-900 text-sm">{notification.user}</span>
                <span className="text-zinc-500 text-xs">•</span>
                <span className="text-zinc-500 text-xs flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {notification.location}
                </span>
              </div>
              <div className="text-zinc-700 text-sm mb-1">
                Downloaded <span className="font-semibold">{notification.game}</span>
              </div>
              <div className="flex items-center gap-2">
                <Star className="w-3 h-3 text-yellow-500 fill-current" />
                <span className="text-xs text-zinc-500">{notification.time}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default NotificationPopup;
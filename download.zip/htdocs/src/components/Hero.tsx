import React, { useState, useEffect } from 'react';
import { Star, Download, Zap, Shield, Crown } from 'lucide-react';
import CountdownTimer from './CountdownTimer';
import LiveCounter from './LiveCounter';

const Hero: React.FC = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [currentFeature, setCurrentFeature] = useState(0);

  const features = [
    { icon: Crown, text: "Premium Mods" },
    { icon: Zap, text: "Unlimited Resources" },
    { icon: Shield, text: "100% Safe" },
    { icon: Download, text: "Instant Download" }
  ];

  useEffect(() => {
    setIsLoaded(true);
    
    const featureInterval = setInterval(() => {
      setCurrentFeature((prev) => (prev + 1) % features.length);
    }, 3000);

    return () => clearInterval(featureInterval);
  }, []);

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center px-6 py-20 overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-600 via-purple-700 to-purple-800">
        {/* Pattern Background */}
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
        
        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-yellow-400/20 rounded-full blur-2xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-pink-400/20 rounded-full blur-2xl animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/4 w-36 h-36 bg-blue-400/20 rounded-full blur-2xl animate-pulse delay-2000" />
      </div>

      {/* Content */}
      <div className="container mx-auto max-w-6xl text-center relative z-10">
        <div className={`space-y-8 transition-all duration-1000 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          {/* Urgency Timer */}
          <div className="flex justify-center mb-6">
            <CountdownTimer />
          </div>

          {/* Badge */}
          <div className="inline-flex items-center px-6 py-3 bg-white/20 backdrop-blur-sm rounded-full text-white text-sm font-medium border border-white/30">
            <Star className="w-5 h-5 mr-2 text-yellow-300 fill-current animate-pulse" />
            <span className="font-semibold">TRUSTED BY 1M+ GAMERS WORLDWIDE</span>
          </div>

          {/* Main Title with Animation */}
          <div className="relative">
            <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold text-white leading-tight mb-4">
              Unlock Premium
              <br />
              <span className="relative">
                <span className="bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 bg-clip-text text-transparent animate-pulse">
                  Game Mods
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 bg-clip-text text-transparent blur-xl animate-pulse" />
              </span>
            </h1>
            
            {/* Animated Feature */}
            <div className="flex justify-center mt-6">
              <div className="inline-flex items-center gap-3 px-6 py-3 bg-white/10 backdrop-blur-sm rounded-full border border-white/20">
                <div className="relative">
                  {features.map((feature, index) => (
                    <div
                      key={feature.text}
                      className={`absolute inset-0 flex items-center justify-center transition-all duration-500 ${
                        index === currentFeature ? 'opacity-100 scale-100' : 'opacity-0 scale-0'
                      }`}
                    >
                      <feature.icon className="w-5 h-5 text-amber-400" />
                    </div>
                  ))}
                  <div className="w-5 h-5" />
                </div>
                <span className="text-white font-medium">
                  {features[currentFeature].text}
                </span>
              </div>
            </div>
          </div>

          {/* Enhanced Description */}
          <div className="max-w-4xl mx-auto">
            <p className="text-lg sm:text-xl md:text-2xl text-white/90 leading-relaxed px-4 mb-8">
              Access <span className="font-bold text-amber-400">50+ exclusive mobile game modifications</span> with unlimited resources, 
              unlocked features, and enhanced gameplay. <span className="font-bold text-green-400">Safe, secure, and instant download.</span>
            </p>
            
            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center gap-4 mb-8">
              <div className="flex items-center gap-2 text-white/80 text-sm">
                <Shield className="w-4 h-4 text-green-400" />
                <span>100% Safe</span>
              </div>
              <div className="flex items-center gap-2 text-white/80 text-sm">
                <Zap className="w-4 h-4 text-yellow-400" />
                <span>Instant Access</span>
              </div>
              <div className="flex items-center gap-2 text-white/80 text-sm">
                <Crown className="w-4 h-4 text-purple-400" />
                <span>Premium Quality</span>
              </div>
            </div>
          </div>

          {/* Enhanced CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <button className="group relative overflow-hidden flex items-center justify-center px-8 sm:px-10 py-4 sm:py-5 bg-gradient-to-r from-amber-400 to-amber-600 text-gray-900 rounded-lg font-bold text-base sm:text-lg transition-all duration-300 hover:scale-105 hover:shadow-2xl transform">
              <div className="absolute inset-0 bg-gradient-to-r from-amber-500 to-amber-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="relative flex items-center gap-3">
                <Download className="w-5 sm:w-6 h-5 sm:h-6 group-hover:animate-bounce" />
                <span className="uppercase tracking-wide">Download All Mods - FREE</span>
              </div>
              <div className="absolute inset-0 bg-white/20 transform -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
            </button>

            <div className="px-6 py-3 bg-white/20 backdrop-blur-sm text-white rounded-lg font-semibold border border-white/30 hover:bg-white/30 transition-all duration-300">
              <span className="flex items-center gap-2">
                <Zap className="w-4 h-4" />
                LIMITED TIME: 100% FREE
              </span>
            </div>
          </div>

          {/* Live Counter */}
          <div className="max-w-4xl mx-auto">
            <LiveCounter />
          </div>
        </div>
      </div>

      {/* Bottom Gradient Fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-zinc-50 to-transparent" />
    </section>
  );
};

export default Hero;
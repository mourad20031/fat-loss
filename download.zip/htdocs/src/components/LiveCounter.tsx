import React, { useState, useEffect } from 'react';
import { TrendingUp, Users, Download, Activity } from 'lucide-react';

const LiveCounter: React.FC = () => {
  const [stats, setStats] = useState({
    activeUsers: 524832,
    todayDownloads: 18743,
    onlineNow: 8934,
    satisfactionRate: 98.7
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => ({
        activeUsers: prev.activeUsers + Math.floor(Math.random() * 3) - 1,
        todayDownloads: prev.todayDownloads + Math.floor(Math.random() * 2),
        onlineNow: prev.onlineNow + Math.floor(Math.random() * 5) - 2,
        satisfactionRate: Math.min(99.9, prev.satisfactionRate + (Math.random() * 0.1 - 0.05))
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M+';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(0) + 'K+';
    }
    return num.toString();
  };

  const counterItems = [
    {
      icon: Users,
      label: 'Active Users',
      value: formatNumber(stats.activeUsers),
      color: 'from-blue-500 to-blue-600',
      change: '+12%',
      trending: true
    },
    {
      icon: Download,
      label: "Today's Downloads",
      value: formatNumber(stats.todayDownloads),
      color: 'from-green-500 to-green-600',
      change: '+23%',
      trending: true
    },
    {
      icon: Activity,
      label: 'Online Now',
      value: formatNumber(stats.onlineNow),
      color: 'from-purple-500 to-purple-600',
      change: '+8%',
      trending: true
    },
    {
      icon: TrendingUp,
      label: 'Satisfaction',
      value: stats.satisfactionRate.toFixed(1) + '%',
      color: 'from-amber-500 to-amber-600',
      change: '+0.3%',
      trending: true
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {counterItems.map((item, index) => (
        <div
          key={item.label}
          className="relative group"
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <div className={`absolute inset-0 bg-gradient-to-r ${item.color} rounded-lg blur-lg opacity-20 group-hover:opacity-40 transition-opacity duration-300`} />
          <div className="relative bg-white rounded-lg p-4 border border-zinc-200 hover:shadow-lg transition-all duration-300">
            <div className="flex items-center justify-between mb-2">
              <div className={`p-2 bg-gradient-to-r ${item.color} rounded-lg`}>
                <item.icon className="w-4 h-4 text-white" />
              </div>
              {item.trending && (
                <div className="flex items-center gap-1 text-green-600 text-xs font-medium">
                  <TrendingUp className="w-3 h-3" />
                  <span>{item.change}</span>
                </div>
              )}
            </div>
            <div className="text-2xl font-bold text-zinc-900 mb-1">
              {item.value}
            </div>
            <div className="text-xs text-zinc-600">
              {item.label}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default LiveCounter;
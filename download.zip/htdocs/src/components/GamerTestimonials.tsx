import React, { useState, useEffect } from 'react';
import { Star, MapPin, Download, Shield } from 'lucide-react';

interface GamerTestimonial {
  id: number;
  gamerName: string;
  game: string;
  rating: number;
  comment: string;
  location: string;
  avatar: string;
  verified: boolean;
}

const GamerTestimonials: React.FC = () => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const testimonials: GamerTestimonial[] = [
    {
      id: 1,
      gamerName: "ProGamer_X",
      game: "PUBG Mobile",
      rating: 5,
      comment: "Best mod ever! Aimbot is perfect and never got detected. Been using for 6 months!",
      location: "California, USA",
      avatar: "🎮",
      verified: true
    },
    {
      id: 2,
      gamerName: "NinjaPlayer99",
      game: "Free Fire",
      rating: 5,
      comment: "Unlimited diamonds changed my gameplay! All skins unlocked, no ads. 10/10!",
      location: "London, UK",
      avatar: "🎯",
      verified: true
    },
    {
      id: 3,
      gamerName: "MobileLegend",
      game: "Mobile Legends",
      rating: 5,
      comment: "Auto win feature is insane! All heroes unlocked instantly. Worth every penny!",
      location: "Tokyo, Japan",
      avatar: "⚡",
      verified: true
    },
    {
      id: 4,
      gamerName: "ClashMaster",
      game: "Clash of Clans",
      rating: 5,
      comment: "Unlimited gems and max resources! Built my dream village in minutes. Amazing!",
      location: "Sydney, Australia",
      avatar: "🏆",
      verified: true
    },
    {
      id: 5,
      gamerName: "SpeedRunner",
      game: "Subway Surfers",
      rating: 5,
      comment: "All characters and unlimited coins! High scores every time. Love it!",
      location: "Toronto, Canada",
      avatar: "🚀",
      verified: true
    },
    {
      id: 6,
      gamerName: "FPSKing",
      game: "Call of Duty Mobile",
      rating: 5,
      comment: "Perfect aim and wallhack! Dominate every match. Best COD mod out there!",
      location: "Mumbai, India",
      avatar: "🔥",
      verified: true
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 4000);

    return () => clearInterval(interval);
  }, [testimonials.length]);

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${
          i < rating ? 'text-yellow-400 fill-current' : 'text-zinc-300'
        }`}
      />
    ));
  };

  return (
    <section className="py-12 px-4 bg-white">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-zinc-900 mb-3">
            What Gamers Are Saying
          </h2>
          <p className="text-sm md:text-base text-zinc-700">
            Real reviews from real gamers who love our mods
          </p>
        </div>

        {/* Main Featured Testimonial */}
        <div className="mb-8">
          <div className="bg-gradient-to-r from-purple-600 to-purple-800 rounded-2xl p-1">
            <div className="bg-white rounded-2xl p-6 md:p-8">
              <div className="flex flex-col md:flex-row items-start md:items-center gap-4 mb-4">
                <div className="flex items-center gap-3">
                  <div className="text-3xl md:text-4xl">
                    {testimonials[currentTestimonial].avatar}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-zinc-900 text-lg md:text-xl">
                        {testimonials[currentTestimonial].gamerName}
                      </h3>
                      {testimonials[currentTestimonial].verified && (
                        <div className="bg-green-500 text-white px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1">
                          <Shield className="w-3 h-3" />
                          Verified
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-zinc-600">
                      <span className="font-medium">{testimonials[currentTestimonial].game}</span>
                      <span>•</span>
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {testimonials[currentTestimonial].location}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1 ml-auto">
                  {renderStars(testimonials[currentTestimonial].rating)}
                </div>
              </div>
              
              <blockquote className="text-zinc-700 text-base md:text-lg leading-relaxed mb-4">
                "{testimonials[currentTestimonial].comment}"
              </blockquote>
              
              <div className="flex items-center gap-2 text-sm text-zinc-500">
                <Download className="w-4 h-4" />
                <span>Downloaded and tested by our team</span>
              </div>
            </div>
          </div>
        </div>

        {/* Testimonial Dots */}
        <div className="flex justify-center gap-2 mb-8">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentTestimonial(index)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                index === currentTestimonial
                  ? 'bg-purple-600 w-8'
                  : 'bg-zinc-300 hover:bg-zinc-400'
              }`}
            />
          ))}
        </div>

        {/* Grid of Additional Testimonials */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {testimonials.slice(1, 7).map((testimonial, index) => (
            <div
              key={testimonial.id}
              className="bg-zinc-50 rounded-lg p-4 border border-zinc-200 hover:shadow-md transition-all duration-300"
            >
              <div className="flex items-start gap-3 mb-3">
                <div className="text-2xl">
                  {testimonial.avatar}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold text-zinc-900 text-sm">
                      {testimonial.gamerName}
                    </h4>
                    {testimonial.verified && (
                      <div className="bg-green-500 text-white px-1 py-0.5 rounded text-xs font-medium">
                        ✓
                      </div>
                    )}
                  </div>
                  <div className="text-xs text-zinc-600 mb-2">
                    {testimonial.game} • {testimonial.location}
                  </div>
                  <div className="flex items-center gap-1 mb-2">
                    {renderStars(testimonial.rating)}
                  </div>
                </div>
              </div>
              
              <p className="text-xs text-zinc-700 leading-relaxed line-clamp-3">
                "{testimonial.comment}"
              </p>
            </div>
          ))}
        </div>

        {/* Trust Badge */}
        <div className="text-center mt-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-50 border border-green-200 rounded-full">
            <Shield className="w-4 h-4 text-green-600" />
            <span className="text-sm font-medium text-green-800">
              All reviews from verified gamers
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GamerTestimonials;
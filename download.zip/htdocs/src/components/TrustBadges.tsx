import React from 'react';
import { Shield, CheckCircle, Award, Lock, Globe, Heart } from 'lucide-react';

const TrustBadges: React.FC = () => {
  const badges = [
    {
      icon: Shield,
      title: "100% Secure",
      description: "SSL Encrypted & Virus Scanned",
      color: "from-green-500 to-emerald-600"
    },
    {
      icon: CheckCircle,
      title: "Guaranteed Working",
      description: "All Mods Tested & Verified",
      color: "from-blue-500 to-cyan-600"
    },
    {
      icon: Award,
      title: "Award Winning",
      description: "#1 Mod Platform 2024",
      color: "from-purple-500 to-pink-600"
    },
    {
      icon: Lock,
      title: "Privacy Protected",
      description: "Your Data is 100% Safe",
      color: "from-amber-500 to-orange-600"
    },
    {
      icon: Globe,
      title: "Global Access",
      description: "Works in All Countries",
      color: "from-indigo-500 to-blue-600"
    },
    {
      icon: Heart,
      title: "Loved by Gamers",
      description: "2M+ Happy Customers",
      color: "from-red-500 to-pink-600"
    }
  ];

  return (
    <section className="py-12 px-6 bg-white border-y border-zinc-200">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-zinc-900 mb-2">
            Why Gamers Trust Us
          </h2>
          <p className="text-zinc-600">
            Your safety and satisfaction are our top priorities
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {badges.map((badge, index) => (
            <div
              key={badge.title}
              className="group text-center"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="relative mb-4">
                <div className={`absolute inset-0 bg-gradient-to-r ${badge.color} rounded-2xl blur-xl opacity-0 group-hover:opacity-40 transition-opacity duration-300`} />
                <div className={`relative bg-gradient-to-r ${badge.color} p-4 rounded-2xl transform transition-all duration-300 group-hover:scale-110 group-hover:rotate-3`}>
                  <badge.icon className="w-8 h-8 text-white mx-auto" />
                </div>
              </div>
              <h3 className="font-bold text-zinc-900 mb-1 text-sm">
                {badge.title}
              </h3>
              <p className="text-xs text-zinc-600 leading-relaxed">
                {badge.description}
              </p>
            </div>
          ))}
        </div>

        {/* Security Seals */}
        <div className="mt-12 pt-8 border-t border-zinc-200">
          <div className="flex flex-wrap justify-center items-center gap-8">
            <div className="flex items-center gap-2 text-zinc-600">
              <Shield className="w-5 h-5 text-green-500" />
              <span className="text-sm font-medium">Norton Secured</span>
            </div>
            <div className="flex items-center gap-2 text-zinc-600">
              <Lock className="w-5 h-5 text-blue-500" />
              <span className="text-sm font-medium">McAfee Certified</span>
            </div>
            <div className="flex items-center gap-2 text-zinc-600">
              <Globe className="w-5 h-5 text-purple-500" />
              <span className="text-sm font-medium">GDPR Compliant</span>
            </div>
            <div className="flex items-center gap-2 text-zinc-600">
              <CheckCircle className="w-5 h-5 text-amber-500" />
              <span className="text-sm font-medium">ISO 27001 Certified</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrustBadges;
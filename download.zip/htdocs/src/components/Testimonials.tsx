import React from 'react';

const Testimonials: React.FC = () => {
  const testimonials = [
    {
      initials: 'AT',
      name: 'Alex Thompson',
      game: 'PUBG Mobile Player',
      level: 'Level 150',
      quote: 'The mods are incredible! I\'ve been using them for 6 months with zero issues.'
    },
    {
      initials: 'JM',
      name: 'Jessica Martinez',
      game: 'Free Fire Enthusiast',
      level: '2M+ Downloads',
      quote: 'Best mod site I\'ve ever used! Unlimited diamonds and no bans.'
    },
    {
      initials: 'RC',
      name: 'Ryan Chen',
      game: 'Mobile Legends Pro',
      level: 'Mythic Glory',
      quote: 'These mods changed my gaming experience completely. All features work perfectly.'
    },
    {
      initials: 'SW',
      name: 'Sophia Wilson',
      game: 'Clash of Clans Player',
      level: 'Max TH15',
      quote: 'Unlimited gems and instant building! 100% safe and reliable!'
    },
  ];

  return (
    <section id="testimonials" className="py-20 px-6 bg-white">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-zinc-900 mb-6">
            What Gamers Are Saying
          </h2>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-zinc-50 border border-zinc-200 rounded-lg p-6 hover:shadow-lg transition-all duration-300"
            >
              {/* User Info */}
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-purple-800 text-white rounded-full flex items-center justify-center font-semibold text-sm">
                  {testimonial.initials}
                </div>
                <div className="ml-3">
                  <div className="font-semibold text-zinc-900 text-sm">
                    {testimonial.name}
                  </div>
                  <div className="text-zinc-600 text-xs">
                    {testimonial.game}
                  </div>
                  <div className="text-zinc-400 text-xs">
                    {testimonial.level}
                  </div>
                </div>
              </div>

              {/* Quote */}
              <blockquote className="text-zinc-800 text-sm leading-relaxed">
                "{testimonial.quote}"
              </blockquote>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
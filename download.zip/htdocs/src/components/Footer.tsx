import React from 'react';
import { Mail, Phone, MapPin, Shield, Star } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { label: 'Privacy Policy', href: '#privacy' },
    { label: 'Terms of Service', href: '#terms' },
    { label: 'Support', href: '#support' },
    { label: 'FAQ', href: '#faq' },
  ];

  return (
    <footer className="bg-gradient-to-br from-zinc-900 to-zinc-800 text-white py-16 px-6">
      <div className="container mx-auto max-w-6xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {/* Brand */}
          <div className="text-center md:text-left">
            <div className="font-bold text-2xl bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent mb-4">
              GameMods Pro
            </div>
            <p className="text-zinc-300 text-sm mb-4">
              Your trusted source for premium game modifications. Safe, secure, and updated regularly.
            </p>
            <div className="text-zinc-400 text-sm">
              © {currentYear} GameMods Pro. All rights reserved.
            </div>
          </div>

          {/* Quick Links */}
          <div className="text-center">
            <h3 className="font-semibold text-lg mb-4">Quick Links</h3>
            <div className="space-y-2">
              {quickLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="block text-zinc-300 hover:text-white transition-colors text-sm"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>

          {/* Support */}
          <div className="text-center md:text-right">
            <h3 className="font-semibold text-lg mb-4">Support</h3>
            <p className="text-zinc-300 text-sm mb-2">24/7 Customer Support</p>
            <p className="text-zinc-300 text-sm mb-4">support@gamemodspro.com</p>
            <div className="flex justify-center md:justify-end gap-2">
              <div className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-xs font-medium">
                100% Safe
              </div>
              <div className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full text-xs font-medium">
                Virus Free
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Border */}
        <div className="pt-8 border-t border-zinc-600/50 text-center">
          <p className="text-zinc-400 text-sm">
            Disclaimer: All game modifications are for educational purposes only. Use at your own risk.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
import React from 'react';
import { Crown, Zap, Shield, Download, Star, Lock, Users, Globe } from 'lucide-react';

const Features: React.FC = () => {
  const features = [
    {
      icon: Crown,
      title: "Premium Features",
      description: "Unlock all paid features, skins, and exclusive content for free.",
    },
    {
      icon: Zap,
      title: "Unlimited Resources",
      description: "Get unlimited coins, gems, energy, and in-game currency instantly.",
    },
    {
      icon: Shield,
      title: "100% Safe & Secure",
      description: "All mods are virus-scanned and tested for complete safety.",
    },
    {
      icon: Download,
      title: "Instant Download",
      description: "No waiting, no surveys - direct download with one click.",
    },
    {
      icon: Star,
      title: "Exclusive Mods",
      description: "Access unique modifications not available anywhere else.",
    },
    {
      icon: Lock,
      title: "Anti-Ban Protection",
      description: "Built-in protection to keep your account safe from bans.",
    },
    {
      icon: Users,
      title: "24/7 Support",
      description: "Round-the-clock customer support for any issues.",
    },
    {
      icon: Globe,
      title: "Global Access",
      description: "Works worldwide on all devices and regions.",
    },
  ];

  return (
    <section id="features" className="py-12 px-4 bg-zinc-50">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-zinc-900 mb-3">
            Why Choose Our Game Mods
          </h2>
          <p className="text-sm md:text-base text-zinc-700 max-w-xl mx-auto">
            Premium modifications with exclusive features for the ultimate gaming experience.
          </p>
        </div>

        {/* Features Grid - More Compact */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="group bg-white p-3 md:p-4 rounded-lg border border-zinc-200 text-center hover:shadow-lg hover:scale-105 transition-all duration-300"
            >
              {/* Icon - Smaller */}
              <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-r from-purple-600 to-purple-800 text-white rounded-lg flex items-center justify-center mx-auto mb-2 md:mb-3 group-hover:scale-110 transition-transform">
                <feature.icon className="text-lg md:text-xl" />
              </div>
              
              {/* Content - More Compact */}
              <h3 className="text-sm md:text-base font-semibold text-zinc-900 mb-1 md:mb-2">
                {feature.title}
              </h3>
              <p className="text-xs md:text-sm text-zinc-700 leading-tight">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
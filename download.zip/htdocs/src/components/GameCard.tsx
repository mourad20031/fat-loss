import React, { useState } from 'react';
import { Game } from '../types';
import { Download, Star, Shield, Zap, Crown, Sparkles, Flame, Users, Clock } from 'lucide-react';

interface GameCardProps {
  game: Game;
}

const GameCard: React.FC<GameCardProps> = ({ game }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [downloadCount, setDownloadCount] = useState(game.downloads);

  const getModIcon = (modType: string) => {
    switch (modType) {
      case 'unlimited-money':
        return <Zap className="w-3 h-3" />;
      case 'premium-unlocked':
        return <Crown className="w-3 h-3" />;
      case 'all-features':
        return <Sparkles className="w-3 h-3" />;
      case 'ad-free':
        return <Shield className="w-3 h-3" />;
      default:
        return <Star className="w-3 h-3" />;
    }
  };

  const getModGradient = (modType: string) => {
    switch (modType) {
      case 'unlimited-money':
        return 'from-yellow-400 to-orange-500';
      case 'premium-unlocked':
        return 'from-purple-400 to-pink-500';
      case 'all-features':
        return 'from-blue-400 to-cyan-500';
      case 'ad-free':
        return 'from-green-400 to-emerald-500';
      default:
        return 'from-gray-400 to-gray-500';
    }
  };

  const getRatingColor = (rating: number) => {
    if (rating >= 4.8) return 'text-green-500';
    if (rating >= 4.5) return 'text-yellow-500';
    return 'text-orange-500';
  };

  const handleDownload = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Animate download count
    const currentCount = parseInt(downloadCount.replace(/\D/g, ''));
    setDownloadCount(`${(currentCount + 1).toLocaleString()}+`);
    
    console.log(`Downloading ${game.name}`);
  };

  return (
    <div
      className="group bg-white rounded-xl border border-zinc-200 overflow-hidden hover:shadow-2xl hover:scale-105 transition-all duration-500 cursor-pointer relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Glow Effect */}
      <div className={`absolute inset-0 bg-gradient-to-r ${getModGradient(game.modType)} rounded-xl opacity-0 group-hover:opacity-20 transition-opacity duration-500`} />
      
      {/* Game Image Container */}
      <div className="relative h-40 sm:h-52 overflow-hidden bg-gradient-to-br from-zinc-900 to-zinc-800">
        <img 
          src={game.image} 
          alt={game.name}
          className="w-full h-full object-cover transition-all duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
        
        {/* Game Info Overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-3">
          <div className="text-white text-center">
            <div className="text-lg sm:text-xl font-bold mb-1">
              {game.name}
            </div>
            <div className="text-xs sm:text-sm opacity-90 capitalize">
              {game.category}
            </div>
          </div>
        </div>
        
        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex gap-2">
          {game.isPopular && (
            <div className="relative">
              <div className="absolute inset-0 bg-red-500 rounded-full blur-sm" />
              <div className="relative bg-red-500 text-white px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                <Flame className="w-3 h-3" />
                HOT
              </div>
            </div>
          )}
          {game.isNew && (
            <div className="relative">
              <div className="absolute inset-0 bg-green-500 rounded-full blur-sm" />
              <div className="relative bg-green-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                NEW
              </div>
            </div>
          )}
        </div>
        
        {/* Rating Badge */}
        <div className="absolute top-3 right-3 bg-yellow-400 text-gray-900 px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1">
          <Star className="w-3 h-3 fill-current" />
          {game.rating}
        </div>

        {/* Hover Overlay */}
        {isHovered && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <div className="text-center">
              <div className={`inline-flex p-3 bg-gradient-to-r ${getModGradient(game.modType)} rounded-full mb-2 animate-bounce`}>
                {getModIcon(game.modType)}
              </div>
              <div className="text-white text-sm font-medium">
                {game.modType.replace('-', ' ').toUpperCase()}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Game Details */}
      <div className="p-4">
        {/* Stats Bar */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1 text-xs text-zinc-500">
            <Users className="w-3 h-3" />
            <span>{downloadCount}</span>
          </div>
          <div className="flex items-center gap-1 text-xs text-zinc-500">
            <Clock className="w-3 h-3" />
            <span>{game.size}</span>
          </div>
          <div className="flex items-center text-xs text-green-600 gap-1">
            <Shield className="w-3 h-3" />
            <span>100% Safe</span>
          </div>
        </div>

        {/* Features */}
        <div className="space-y-2 mb-4">
          <div className="flex items-center text-xs text-zinc-700">
            <div className={`inline-flex p-1 bg-gradient-to-r ${getModGradient(game.modType)} rounded mr-2`}>
              {getModIcon(game.modType)}
            </div>
            <span>{game.features.slice(0, 2).join(', ')}</span>
          </div>
          {game.features.length > 2 && (
            <div className="text-xs text-zinc-500">
              +{game.features.length - 2} more features
            </div>
          )}
        </div>

        {/* Download Button */}
        <button
          onClick={handleDownload}
          className={`w-full relative overflow-hidden bg-gradient-to-r ${getModGradient(game.modType)} text-white py-3 rounded-lg font-semibold text-sm hover:opacity-90 transition-all duration-300 transform hover:scale-105 active:scale-95`}
        >
          <div className="absolute inset-0 bg-white/20 transform -skew-x-12 -translate-x-full hover:translate-x-full transition-transform duration-500" />
          <div className="relative flex items-center justify-center gap-2">
            <Download className="w-4 h-4" />
            <span>DOWNLOAD NOW</span>
          </div>
        </button>
      </div>
    </div>
  );
};

export default GameCard;
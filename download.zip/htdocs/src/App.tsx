import React, { useEffect, useState } from 'react';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import Features from './components/Features';
import TrustBadges from './components/TrustBadges';
import GameShowcase from './components/GameShowcase';
import GamerTestimonials from './components/GamerTestimonials';
import Contact from './components/Contact';
import CTA from './components/CTA';
import Footer from './components/Footer';
import NotificationPopup from './components/NotificationPopup';

function App() {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
    
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLAnchorElement;
      if (target.hash) {
        e.preventDefault();
        const element = document.querySelector(target.hash);
        if (element) {
          element.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }
      }
    };

    document.addEventListener('click', handleAnchorClick);
    return () => document.removeEventListener('click', handleAnchorClick);

    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-in');
        }
      });
    }, observerOptions);

    setTimeout(() => {
      document.querySelectorAll('section').forEach(section => {
        observer.observe(section);
      });
    }, 100);
  }, []);

  return (
    <div className={`min-h-screen bg-white text-zinc-900 overflow-x-hidden ${isLoaded ? 'loaded' : ''}`}>
      <Navigation />
      <Hero />
      <TrustBadges />
      <Features />
      <GameShowcase />
      <GamerTestimonials />
      <Contact />
      <CTA />
      <Footer />
      <NotificationPopup />
    </div>
  );
}

export default App;
export interface Game {
  id: string;
  name: string;
  category: string;
  description: string;
  features: string[];
  size: string;
  version: string;
  rating: number;
  downloads: string;
  image: string;
  downloadUrl: string;
  modType: 'unlimited-money' | 'premium-unlocked' | 'all-features' | 'ad-free' | 'custom';
  isNew?: boolean;
  isPopular?: boolean;
}